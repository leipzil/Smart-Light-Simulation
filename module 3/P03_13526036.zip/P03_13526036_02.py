# SID/Name : 13526036/Levina Nirwasita
# Date : 26/10/26
# Description : alternating between tables + time taken for each and total

N = int(input("Enter the number of tables (N): "))
table = []
for x in range(N):
    temp = int(input(f"Enter the time for table {x+1}: "))
    table.append(temp)
v = 1
m = 1
index = 0
time_v = table[0]
time_m = table[N-1]
count = 2
index += 1
while count < N:
    if count == N-1 and time_v == time_m:
        time_v += table[v+1]
        v += 1
    while time_m < time_v:
        if index == 1:
            time_m += table[N-1-index]
        else:
            time_m += table[N-index]
        m += 1
        count += 1
        index += 1
    while time_v < time_m:
        time_v += table[index]
        v += 1
        count += 1
        index += 1
print(f"Mr. Vin clears {v} tables")
print(f"Mr. Mik clears {m} tables")
print(f"All tables are cleared in {time_v+time_m} minutes")